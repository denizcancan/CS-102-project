package com.example.gym;

public class User {
    public String name,email;
    public int id_number;
    public String password;

    public User(String name,String email,int id_number,String password){
        this.name=name;
        this.email=email;
        this.id_number=id_number;
        this.password=password;
    }

    public String getName(){
        return this.name;
    }
}
