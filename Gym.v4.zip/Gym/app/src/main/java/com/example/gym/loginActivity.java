package com.example.gym;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class loginActivity extends AppCompatActivity {

    private EditText editTextTextEmailAddressLogin;
    private EditText editTextPassword;
    private Button loginbutton;
    private ProgressBar progressBar;
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseUser firebaseUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextTextEmailAddressLogin=findViewById(R.id.editTextTextEmailAddressLogin);
        editTextPassword=findViewById(R.id.editTextPassword);
        loginbutton=findViewById(R.id.loginbutton);
        progressBar=findViewById(R.id.progressBar);
        mAuth=FirebaseAuth.getInstance();

        firebaseUser = mAuth.getCurrentUser(); // registered user

        if(firebaseUser == null){ // check if the user is valid

            Intent i = new Intent(loginActivity.this,MainActivity.class);
            startActivity(i);
            finish();
        }


        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUser();
            }
        });
    }

    private void loginUser(){

        String email=editTextTextEmailAddressLogin.getText().toString();
        String userPassword=editTextPassword.getText().toString();
        mAuth.signInWithEmailAndPassword(email,userPassword).addOnCompleteListener(loginActivity.this,
                new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){

                            Intent i = new Intent(loginActivity.this,menu.class);
                            Toast.makeText(loginActivity.this,"Welcome"+mUser.getDisplayName(),Toast.LENGTH_LONG).show();
                            startActivity(i);

                            finish();

                        }
                        else{
                            Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }

                });
    }
        /*String email=editTextTextEmailAddressLogin.getText().toString().trim();
        String password=editTextPassword.getText().toString();


        progressBar.setVisibility(View.VISIBLE);
        mAuth.signInWithEmailAndPassword(email,password).addOnSuccessListener(this, new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                mUser=mAuth.getCurrentUser();
                progressBar.setVisibility(View.GONE);
                //Toast.makeText(loginActivity.this,"Welcome"+mUser.getEmail(),Toast.LENGTH_LONG).show();
                startActivity(new Intent(loginActivity.this,menu.class));
            }
        }).addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(loginActivity.this,"Login process is not succesfull",Toast.LENGTH_LONG).show();
            }
        });
        /*if(task.isSuccessful())
        {
            progressBar.setVisibility(View.GONE);
            startActivity(new Intent(loginActivity.this,menu.class));
        }
        else{
            progressBar.setVisibility(View.GONE);
            Toast.makeText(loginActivity.this,"Login process is not succesfull",Toast.LENGTH_LONG).show();
        }*/



    private boolean bilkentMailChecker(String email){
        boolean check=true;
        int start=email.indexOf('@');
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            return false;
        }
        if(!email.substring(start).equals("@ug.bilkent.edu.tr"))
        {
            check=false;
        }
        return check;
    }
}