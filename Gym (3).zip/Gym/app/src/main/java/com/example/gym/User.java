package com.example.gym;

public class User {
    public String name,email;
    public int id_number;
    private String password;

    public User(String name,String email,int id_number){
        this.name=name;
        this.email=email;
        this.id_number=id_number;

    }

    public String getName(){
        return this.name;
    }
}
